package com.techavalanche.oneToOne.fk;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class JPATest {

	private static String PERSISTENCE_UNIT_NAME = "perContext-Hibernate";
	private static EntityManager entityManager;
	
	public static void main(String[] args) {
		
		if(args.length != 0 && args[0] != null)
			PERSISTENCE_UNIT_NAME = args[0];
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		entityManager = factory.createEntityManager();
		
		createPerson();
		
		getAllPersons();
		
	}
	
	public static void getAllPersons(){
		Query query = entityManager.createQuery("SELECT person FROM Person person");
		
		List<Person> lstPerson = query.getResultList();
		
		for (Person person1 : lstPerson) {
			System.out.println("-----------------------------------------------------------------------------------------");
			System.out.println("[ "+person1.toString()+" ]");
			if(person1.getPassport() != null)
				System.out.println("[ Passport No : "+person1.getPassport().getPassportNo()+" ]");
			else
				System.out.println("[ Passport No : Not Applicable ]");
			System.out.println("-----------------------------------------------------------------------------------------");
		}
	}
	
	public static void createPerson(){
		
		entityManager.getTransaction().begin();

		Person person = new Person();
		person.setName("Ninad Kamerkar");
		
		Passport passport = new Passport();
		passport.setPassportNo("GHABD877H");
		
		person.setPassport(passport);
		
		entityManager.persist(person);
		
		entityManager.getTransaction().commit();
	}
}
